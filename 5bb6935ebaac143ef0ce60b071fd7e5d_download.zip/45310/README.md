# Notcoin

Notcoin is a simulated cryptocurrency project created using HTML, CSS, and JavaScript.

# Installation
To get started with Notcoin, follow these steps:

- Clone the repository:
```
git clone https://github.com/yourusername/notcoin.git
```

- Navigate to the project directory:
```
cd notcoin
```

- Open the index.html file in your web browser:
You can open the index.html file directly in your browser or use a local server for a better development experience.

# License
Distributed under the MIT License. See LICENSE for more information.
